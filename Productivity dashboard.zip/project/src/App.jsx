import { useState } from 'react'
import { format } from 'date-fns'
import './App.css'

const mockUsers = [
  { id: 1, name: 'Alice Johnson', tasks: 45, completion: 92, hours: 38 },
  { id: 2, name: 'Bob Smith', tasks: 32, completion: 78, hours: 35 },
  { id: 3, name: 'Carol Williams', tasks: 51, completion: 95, hours: 42 },
  { id: 4, name: 'David Brown', tasks: 28, completion: 85, hours: 33 },
  { id: 5, name: 'Eve Davis', tasks: 39, completion: 88, hours: 37 }
]

function App() {
  const [sortField, setSortField] = useState('name')
  const [sortDirection, setSortDirection] = useState('asc')

  const sortedUsers = [...mockUsers].sort((a, b) => {
    const modifier = sortDirection === 'asc' ? 1 : -1
    if (a[sortField] < b[sortField]) return -1 * modifier
    if (a[sortField] > b[sortField]) return 1 * modifier
    return 0
  })

  const handleSort = (field) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('asc')
    }
  }

  const totalTasks = mockUsers.reduce((sum, user) => sum + user.tasks, 0)
  const averageCompletion = (mockUsers.reduce((sum, user) => sum + user.completion, 0) / mockUsers.length).toFixed(1)
  const totalHours = mockUsers.reduce((sum, user) => sum + user.hours, 0)

  return (
    <div className="dashboard">
      <h1>Productivity Dashboard</h1>
      
      <div className="metrics-summary">
        <div className="metric">
          <h3>Total Tasks</h3>
          <p>{totalTasks}</p>
        </div>
        <div className="metric">
          <h3>Avg Completion</h3>
          <p>{averageCompletion}%</p>
        </div>
        <div className="metric">
          <h3>Total Hours</h3>
          <p>{totalHours}h</p>
        </div>
        <div className="metric">
          <h3>Last Updated</h3>
          <p>{format(new Date(), 'MMM d, yyyy')}</p>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th onClick={() => handleSort('name')}>
                Name {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('tasks')}>
                Tasks {sortField === 'tasks' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('completion')}>
                Completion {sortField === 'completion' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('hours')}>
                Hours {sortField === 'hours' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedUsers.map(user => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.tasks}</td>
                <td>{user.completion}%</td>
                <td>{user.hours}h</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default App